package aprovados.myapplication.ui.flashcards

import androidx.fragment.app.Fragment
import aprovados.myapplication.R

class FlashcardsFragment : Fragment(R.layout.fragment_flashcards)
