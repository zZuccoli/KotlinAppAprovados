package aprovados.myapplication.ui.calendario

import androidx.fragment.app.Fragment
import aprovados.myapplication.R

class CalendarioFragment : Fragment(R.layout.fragment_calendario)
